"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  BarChart3,
  Brain,
  Target,
  Smile,
  TrendingUp,
  Sparkles,
  Heart,
  ThumbsUp,
  ThumbsDown,
  Meh,
  Crown,
  Activity,
  Settings,
} from "lucide-react"

// Enhanced sentiment analysis function
function analyzeSentiment(text: string) {
  const positiveWords = [
    "happy",
    "joy",
    "love",
    "excellent",
    "amazing",
    "wonderful",
    "great",
    "good",
    "fantastic",
    "awesome",
    "brilliant",
    "perfect",
    "beautiful",
    "nice",
    "pleasant",
    "delighted",
    "thrilled",
    "excited",
    "cheerful",
    "optimistic",
    "satisfied",
    "grateful",
    "blessed",
    "lucky",
    "proud",
  ]

  const negativeWords = [
    "sad",
    "angry",
    "hate",
    "terrible",
    "awful",
    "horrible",
    "bad",
    "worst",
    "disgusting",
    "annoying",
    "frustrated",
    "disappointed",
    "depressed",
    "upset",
    "worried",
    "anxious",
    "stressed",
    "furious",
    "devastated",
    "heartbroken",
    "miserable",
  ]

  const neutralWords = ["okay", "fine", "normal", "average", "standard", "typical", "regular", "ordinary"]

  const words = text.toLowerCase().split(/\s+/)
  let positiveScore = 0
  let negativeScore = 0
  let neutralScore = 0
  const totalWords = words.length
  const sentimentWords = []

  words.forEach((word) => {
    const cleanWord = word.replace(/[^\w]/g, "")
    if (positiveWords.includes(cleanWord)) {
      positiveScore++
      sentimentWords.push({ word: cleanWord, type: "positive" })
    }
    if (negativeWords.includes(cleanWord)) {
      negativeScore++
      sentimentWords.push({ word: cleanWord, type: "negative" })
    }
    if (neutralWords.includes(cleanWord)) {
      neutralScore++
      sentimentWords.push({ word: cleanWord, type: "neutral" })
    }
  })

  const confidence = Math.min(((positiveScore + negativeScore + neutralScore) / totalWords) * 100, 100)

  let sentiment, emoji, description, emotionName
  if (positiveScore > negativeScore && positiveScore > neutralScore) {
    sentiment = "positive"
    emoji = "😂"
    emotionName = "Joy"
    description = "Positive sentiment detected"
  } else if (negativeScore > positiveScore && negativeScore > neutralScore) {
    sentiment = "negative"
    emoji = "😢"
    emotionName = "Sadness"
    description = "Negative sentiment detected"
  } else {
    sentiment = "neutral"
    emoji = "😐"
    emotionName = "Neutral"
    description = "Neutral sentiment detected"
  }

  return {
    sentiment,
    emoji,
    emotionName,
    score: Math.abs(positiveScore - negativeScore),
    description,
    confidence: Math.round(confidence),
    breakdown: {
      positive: positiveScore,
      negative: negativeScore,
      neutral: neutralScore,
      total: totalWords,
    },
    sentimentWords,
    wordCount: totalWords,
    characterCount: text.length,
  }
}

export default function SentiMindAI() {
  const [inputText, setInputText] = useState("happy")
  const [result, setResult] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [activeTab, setActiveTab] = useState("breakdown")
  const [selectedEmoji, setSelectedEmoji] = useState<string | null>(null)
  const [realTimeAnalysis, setRealTimeAnalysis] = useState(true)
  const [scrollY, setScrollY] = useState(0)
  const [isTyping, setIsTyping] = useState(false)
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value)

    // Set typing state to true
    setIsTyping(true)

    // Clear existing timeout
    if (typingTimeout) {
      clearTimeout(typingTimeout)
    }

    // Set new timeout to stop typing animation after 1 second of inactivity
    const newTimeout = setTimeout(() => {
      setIsTyping(false)
    }, 1000)

    setTypingTimeout(newTimeout)
  }

  const handleAnalyze = async () => {
    if (!inputText.trim()) return

    setIsAnalyzing(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const analysis = analyzeSentiment(inputText)
    setResult(analysis)
    setSelectedEmoji(analysis.emoji)
    setIsAnalyzing(false)
  }

  const copyEmoji = (emoji: string) => {
    navigator.clipboard.writeText(emoji)
    // Show a temporary tooltip
    const tooltip = document.createElement("div")
    tooltip.textContent = "Copied!"
    tooltip.className =
      "fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-green-500 text-white text-sm px-3 py-2 rounded-lg z-50 shadow-lg"
    document.body.appendChild(tooltip)
    setTimeout(() => document.body.removeChild(tooltip), 1000)
  }

  const emojiCategories = {
    positive: [
      { emoji: "😊", name: "Happy" },
      { emoji: "😄", name: "Joyful" },
      { emoji: "🥳", name: "Celebrating" },
      { emoji: "😍", name: "Love" },
      { emoji: "🤩", name: "Star-struck" },
      { emoji: "😎", name: "Cool" },
      { emoji: "🥰", name: "Loving" },
      { emoji: "😘", name: "Kiss" },
    ],
    negative: [
      { emoji: "😢", name: "Sad" },
      { emoji: "😭", name: "Crying" },
      { emoji: "😠", name: "Angry" },
      { emoji: "😡", name: "Furious" },
      { emoji: "😤", name: "Huffing" },
      { emoji: "😰", name: "Anxious" },
      { emoji: "😨", name: "Fearful" },
      { emoji: "😱", name: "Shocked" },
    ],
    neutral: [
      { emoji: "😐", name: "Neutral" },
      { emoji: "😑", name: "Expressionless" },
      { emoji: "🤔", name: "Thinking" },
      { emoji: "😶", name: "No mouth" },
      { emoji: "🙄", name: "Eye roll" },
      { emoji: "😏", name: "Smirking" },
      { emoji: "🤨", name: "Raised eyebrow" },
      { emoji: "😒", name: "Unamused" },
    ],
  }

  // Confusion Matrix Data
  const confusionMatrix = [
    { emotion: "Joy", Joy: 86, Anger: 0, Fear: 0, Sadness: 0, Surprise: 0, Disgust: 0, Love: 0, Trust: 0 },
    { emotion: "Anger", Joy: 0, Anger: 88, Fear: 0, Sadness: 0, Surprise: 0, Disgust: 0, Love: 0, Trust: 0 },
    { emotion: "Fear", Joy: 0, Anger: 0, Fear: 95, Sadness: 0, Surprise: 0, Disgust: 0, Love: 0, Trust: 0 },
    { emotion: "Sadness", Joy: 0, Anger: 0, Fear: 0, Sadness: 93, Surprise: 0, Disgust: 0, Love: 0, Trust: 0 },
    { emotion: "Surprise", Joy: 0, Anger: 0, Fear: 0, Sadness: 0, Surprise: 92, Disgust: 0, Love: 0, Trust: 0 },
    { emotion: "Disgust", Joy: 0, Anger: 0, Fear: 0, Sadness: 0, Surprise: 0, Disgust: 94, Love: 0, Trust: 0 },
    { emotion: "Love", Joy: 0, Anger: 0, Fear: 0, Sadness: 0, Surprise: 0, Disgust: 0, Love: 89, Trust: 0 },
    { emotion: "Trust", Joy: 0, Anger: 0, Fear: 0, Sadness: 0, Surprise: 0, Disgust: 0, Love: 0, Trust: 94 },
  ]

  const emotions = ["Joy", "Anger", "Fear", "Sadness", "Surprise", "Disgust", "Love", "Trust"]

  // Auto-analyze on component mount
  useState(() => {
    if (inputText === "happy") {
      handleAnalyze()
    }
  })

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        {/* Subtle gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/50 via-slate-950 to-slate-900/50"></div>

        {/* Floating Particles - Always floating slowly, faster when typing */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-slate-600/15 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: isTyping ? `${1 + Math.random() * 1}s` : `${8 + Math.random() * 4}s`,
              transform: isTyping
                ? `translateY(${scrollY * (0.1 + Math.random() * 0.3)}px) translateX(${scrollY * (Math.random() * 0.1 - 0.05)}px) scale(${1 + Math.sin(Date.now() * 0.002 + i) * 0.3})`
                : `translateY(${scrollY * (0.02 + Math.random() * 0.05)}px) translateX(${scrollY * (Math.random() * 0.02 - 0.01)}px)`,
              transition: "transform 0.3s ease-out, animation-duration 0.5s ease-out",
              opacity: isTyping ? 0.3 : 0.15,
            }}
          />
        ))}

        {/* Additional larger floating elements - Always floating slowly, faster when typing */}
        {[...Array(8)].map((_, i) => (
          <div
            key={`large-${i}`}
            className="absolute w-2 h-2 bg-purple-500/10 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: isTyping ? `${2 + Math.random() * 2}s` : `${12 + Math.random() * 6}s`,
              transform: isTyping
                ? `translateY(${scrollY * (0.2 + Math.random() * 0.4)}px) translateX(${scrollY * (Math.random() * 0.15 - 0.075)}px) scale(${1 + Math.sin(scrollY * 0.01 + i) * 0.3})`
                : `translateY(${scrollY * (0.03 + Math.random() * 0.1)}px) translateX(${scrollY * (Math.random() * 0.03 - 0.015)}px)`,
              transition: "transform 0.5s ease-out, animation-duration 0.5s ease-out",
              opacity: isTyping ? 0.2 : 0.1,
            }}
          />
        ))}

        {/* Floating gradient orbs - Always floating slowly, faster when typing */}
        {[...Array(5)].map((_, i) => (
          <div
            key={`orb-${i}`}
            className="absolute w-8 h-8 bg-gradient-to-r from-purple-500/5 to-blue-500/5 rounded-full blur-sm"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transform: isTyping
                ? `translateY(${scrollY * (0.05 + Math.random() * 0.2)}px) translateX(${scrollY * (Math.random() * 0.1 - 0.05)}px) rotate(${scrollY * 0.1}deg) scale(${1 + Math.sin(Date.now() * 0.001 + i) * 0.3})`
                : `translateY(${scrollY * (0.01 + Math.random() * 0.03)}px) translateX(${scrollY * (Math.random() * 0.02 - 0.01)}px) rotate(${scrollY * 0.02}deg)`,
              transition: "transform 0.7s ease-out",
              opacity: isTyping ? 0.15 : 0.05,
              animation: isTyping
                ? `float-fast-${i} ${3 + Math.random() * 2}s ease-in-out infinite`
                : `float-slow-${i} ${15 + Math.random() * 10}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Add CSS animations for floating */}
      <style jsx>{`
        @keyframes float-slow-0 { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-10px) rotate(5deg); } }
        @keyframes float-slow-1 { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-8px) rotate(-3deg); } }
        @keyframes float-slow-2 { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-12px) rotate(7deg); } }
        @keyframes float-slow-3 { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-6px) rotate(-5deg); } }
        @keyframes float-slow-4 { 0%, 100% { transform: translateY(0px) rotate(0deg); } 50% { transform: translateY(-9px) rotate(4deg); } }
        
        @keyframes float-fast-0 { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-20px) rotate(15deg) scale(1.2); } }
        @keyframes float-fast-1 { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-25px) rotate(-12deg) scale(1.1); } }
        @keyframes float-fast-2 { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-18px) rotate(20deg) scale(1.3); } }
        @keyframes float-fast-3 { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-22px) rotate(-8deg) scale(1.15); } }
        @keyframes float-fast-4 { 0%, 100% { transform: translateY(0px) rotate(0deg) scale(1); } 50% { transform: translateY(-16px) rotate(10deg) scale(1.25); } }
      `}</style>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-6 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-full p-4 shadow-2xl">
              <div className="flex items-center space-x-2 text-white">
                <Brain className="w-6 h-6" />
                <Heart className="w-5 h-5 animate-bounce" />
                <Sparkles className="w-5 h-5" />
              </div>
            </div>
          </div>

          <h1 className="text-6xl md:text-7xl font-black bg-gradient-to-r from-purple-300 via-blue-300 to-cyan-300 bg-clip-text text-transparent mb-4 drop-shadow-2xl tracking-tight">
            SentiMind
          </h1>
          <p className="text-slate-400 text-lg mb-8">Advanced Emotional Intelligence Analysis Platform</p>

          {/* Status Indicators */}
          <div className="flex justify-center items-center space-x-6 mb-8">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-sm">Online</span>
            </div>
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
              <Activity className="w-3 h-3 mr-1" />
              Real-time Ready
            </Badge>
            {isTyping && (
              <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 animate-pulse">
                <Brain className="w-3 h-3 mr-1" />
                Thinking...
              </Badge>
            )}
          </div>
        </div>

        {/* Main Interface */}
        <div className="max-w-4xl mx-auto">
          {/* Text Input Section */}
          <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm mb-8 shadow-xl">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-purple-400" />
                    <span className="text-white font-medium">Text Input</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    {/* Real-time Analysis Toggle */}
                    <div className="flex items-center space-x-2">
                      <Activity className={`w-4 h-4 ${realTimeAnalysis ? "text-green-400" : "text-slate-400"}`} />
                      <span className={`text-sm ${realTimeAnalysis ? "text-green-400" : "text-white"}`}>Real-time</span>
                      <Switch
                        checked={realTimeAnalysis}
                        onCheckedChange={setRealTimeAnalysis}
                        className={`${realTimeAnalysis ? "data-[state=checked]:bg-green-500" : "data-[state=unchecked]:bg-slate-600"}`}
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <kbd className="px-2 py-1 bg-slate-700/50 text-slate-300 text-xs rounded border border-slate-600">
                        Ctrl+Enter
                      </kbd>
                      <span className="text-slate-400 text-xs">to analyze</span>
                    </div>
                  </div>
                </div>

                <Textarea
                  value={inputText}
                  onChange={handleTextChange}
                  className={`min-h-[120px] bg-slate-800/80 border-slate-600/50 text-white placeholder:text-slate-500 resize-none focus:ring-2 focus:ring-purple-500/50 transition-all duration-300 text-lg ${
                    isTyping ? "ring-2 ring-purple-400/30 shadow-lg shadow-purple-500/10" : ""
                  }`}
                  placeholder="Enter your text here to analyze sentiment..."
                />

                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-4 text-sm text-slate-400">
                    <span>{inputText.length} characters</span>
                    <div className="flex items-center space-x-1">
                      <div
                        className={`w-2 h-2 rounded-full transition-colors duration-300 ${isTyping ? "bg-purple-400 animate-pulse" : "bg-green-400"}`}
                      ></div>
                      <div
                        className={`w-2 h-2 rounded-full transition-colors duration-300 ${isTyping ? "bg-blue-400 animate-pulse" : "bg-blue-400"}`}
                      ></div>
                    </div>
                  </div>
                  <button
                    onClick={() => setInputText("")}
                    className="px-4 py-2 bg-slate-700/50 hover:bg-slate-600/50 text-slate-300 rounded-lg transition-colors duration-200 text-sm"
                  >
                    Clear
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Analyze Button */}
          <div className="mb-8">
            <button
              onClick={handleAnalyze}
              disabled={!inputText.trim() || isAnalyzing}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-4 px-8 rounded-xl shadow-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center space-x-3 text-lg"
            >
              {isAnalyzing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Analyzing Sentiment...</span>
                </>
              ) : (
                <>
                  <Brain className="w-5 h-5" />
                  <span>Analyze Sentiment</span>
                  <Sparkles className="w-5 h-5" />
                </>
              )}
            </button>
          </div>

          {/* Results Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-6 bg-slate-900/60 border border-slate-700/50 backdrop-blur-sm rounded-xl p-1">
              <TabsTrigger
                value="primary"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <Heart className="w-4 h-4" />
                <span className="hidden sm:inline">Primary</span>
              </TabsTrigger>
              <TabsTrigger
                value="breakdown"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">Breakdown</span>
              </TabsTrigger>
              <TabsTrigger
                value="emojis"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <Smile className="w-4 h-4" />
                <span className="hidden sm:inline">Emojis</span>
              </TabsTrigger>
              <TabsTrigger
                value="accuracy"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <Target className="w-4 h-4" />
                <span className="hidden sm:inline">Accuracy</span>
              </TabsTrigger>
              <TabsTrigger
                value="eda"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <Brain className="w-4 h-4" />
                <span className="hidden sm:inline">EDA</span>
              </TabsTrigger>
              <TabsTrigger
                value="summary"
                className="text-slate-300 data-[state=active]:bg-purple-600 data-[state=active]:text-white transition-all duration-300 rounded-lg flex items-center space-x-2"
              >
                <TrendingUp className="w-4 h-4" />
                <span className="hidden sm:inline">Summary</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="primary" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="text-center space-y-8">
                      <div
                        className="text-8xl mb-6 cursor-pointer hover:scale-110 transition-transform duration-300"
                        onClick={() => copyEmoji(result.emoji)}
                        title="Click to copy"
                      >
                        {result.emoji}
                      </div>
                      <div className="space-y-6">
                        <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 text-xl hover:scale-105 transition-transform duration-300 cursor-pointer shadow-lg rounded-xl">
                          {result.sentiment.toUpperCase()} SENTIMENT
                        </Badge>
                        <p className="text-white text-2xl font-medium">{result.description}</p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                          <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 hover:scale-105 transition-all duration-300">
                            <p className="text-slate-300 text-sm mb-2">Confidence</p>
                            <p className="font-bold text-white text-3xl mb-3">{result.confidence}%</p>
                            <div className="w-full bg-slate-700 rounded-full h-2">
                              <div
                                className="h-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-1000"
                                style={{ width: `${result.confidence}%` }}
                              />
                            </div>
                          </div>
                          <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 hover:scale-105 transition-all duration-300">
                            <p className="text-slate-300 text-sm mb-2">Intensity</p>
                            <p className="font-bold text-white text-3xl mb-3">{result.score}</p>
                            <div className="flex items-center">
                              {result.sentiment === "positive" && <ThumbsUp className="w-4 h-4 text-green-400 mr-2" />}
                              {result.sentiment === "negative" && <ThumbsDown className="w-4 h-4 text-red-400 mr-2" />}
                              {result.sentiment === "neutral" && <Meh className="w-4 h-4 text-slate-400 mr-2" />}
                              <span className="text-xs text-slate-400">
                                {result.score < 2 ? "Mild" : result.score < 5 ? "Moderate" : "Strong"}
                              </span>
                            </div>
                          </div>
                          <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 hover:scale-105 transition-all duration-300">
                            <p className="text-slate-300 text-sm mb-2">Words</p>
                            <p className="font-bold text-white text-3xl mb-3">{result.wordCount}</p>
                            <p className="text-xs text-slate-400">
                              {result.wordCount < 50
                                ? "Short text"
                                : result.wordCount < 200
                                  ? "Medium text"
                                  : "Long text"}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <div className="text-6xl mb-6">🤔</div>
                      <p className="text-slate-400 text-lg mb-6">Enter some text and click analyze to see results</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="breakdown" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="space-y-6">
                      <div className="flex items-center space-x-3 mb-6">
                        <BarChart3 className="w-6 h-6 text-slate-300" />
                        <h3 className="text-white text-2xl font-bold">Interactive Emotion Analysis</h3>
                      </div>
                      <p className="text-slate-400 mb-8">
                        Detected {result.breakdown.positive + result.breakdown.negative + result.breakdown.neutral}{" "}
                        emotional words out of {result.breakdown.total} total words
                      </p>

                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center justify-between mb-6">
                          <div className="flex items-center space-x-4">
                            <div className="text-4xl">{result.emoji}</div>
                            <div>
                              <h4 className="text-white text-xl font-semibold">{result.emotionName}</h4>
                              <Badge className="bg-red-600/20 text-red-400 border-red-600/30 mt-1">
                                high intensity
                              </Badge>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <div className="text-right">
                              <div className="text-white text-2xl font-bold">100%</div>
                            </div>
                            <Badge className="bg-slate-700/50 text-slate-300">{result.wordCount} words</Badge>
                            <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                              {result.confidence}% conf.
                            </Badge>
                          </div>
                        </div>

                        <div className="mb-4">
                          <p className="text-slate-400 text-sm mb-2">Related emojis:</p>
                          <div className="flex space-x-2">
                            {["😍", "🤗", "🥰", "🎉"].map((emoji, index) => (
                              <span
                                key={index}
                                className="text-2xl cursor-pointer hover:scale-110 transition-transform duration-200 hover:bg-slate-700/50 rounded-lg p-2 relative group"
                                onClick={() => copyEmoji(emoji)}
                                title="Click to copy"
                              >
                                {emoji}
                                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap">
                                  Click to copy
                                </div>
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="w-full bg-slate-700 rounded-full h-2">
                          <div className="h-2 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full transition-all duration-1000 w-full" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <BarChart3 className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                      <p className="text-slate-400 text-lg">No breakdown data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="emojis" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="space-y-8">
                      {/* Only show the category that matches the current result */}
                      {Object.entries(emojiCategories).map(([category, emojis]) => {
                        // Only render if this category matches the current sentiment
                        if (result.sentiment !== category) return null

                        return (
                          <div key={category} className="space-y-4">
                            <h4 className="text-white font-semibold capitalize text-lg flex items-center">
                              <div
                                className={`w-3 h-3 rounded-full mr-3 ${
                                  category === "positive"
                                    ? "bg-green-400"
                                    : category === "negative"
                                      ? "bg-red-400"
                                      : "bg-slate-400"
                                }`}
                              ></div>
                              {category} Expressions
                              <Badge className="ml-3 bg-purple-600 text-white">
                                <Crown className="w-3 h-3 mr-1" />
                                Current Match Category
                              </Badge>
                            </h4>
                            <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
                              {emojis.map((emojiData, index) => (
                                <div
                                  key={index}
                                  className={`
                        text-3xl p-4 rounded-xl cursor-pointer transition-all duration-300 hover:scale-110 relative group
                        ${
                          result.emoji === emojiData.emoji
                            ? "bg-purple-600 ring-2 ring-white shadow-2xl"
                            : "bg-slate-800/60 hover:bg-slate-700/60"
                        }
                        border border-slate-700/50
                      `}
                                  onClick={() => copyEmoji(emojiData.emoji)}
                                  title="Click to copy"
                                >
                                  {emojiData.emoji}
                                  {result.emoji === emojiData.emoji && (
                                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-lg">
                                      <Crown className="w-3 h-3 text-black" />
                                    </div>
                                  )}
                                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap">
                                    Click to copy
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <Smile className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                      <p className="text-slate-400 text-lg mb-6">Run an analysis to see matching expressions</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="accuracy" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="space-y-8">
                      {/* Header */}
                      <div className="flex items-center space-x-3 mb-6">
                        <Target className="w-6 h-6 text-slate-300" />
                        <div>
                          <h3 className="text-white text-2xl font-bold">Model Accuracy & Confidence</h3>
                          <p className="text-slate-400 text-sm">
                            Detailed metrics about prediction reliability and model performance
                          </p>
                        </div>
                      </div>

                      {/* Overall Confidence */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            <TrendingUp className="w-5 h-5 text-slate-300" />
                            <span className="text-white font-semibold">Overall Confidence</span>
                          </div>
                          <Badge className="bg-green-600/20 text-green-400 border-green-600/30">95%</Badge>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-3 mb-3">
                          <div className="bg-gradient-to-r from-green-400 to-emerald-500 h-3 rounded-full transition-all duration-1000 w-[95%]" />
                        </div>
                        <p className="text-slate-400 text-sm">
                          Prediction Reliability: <span className="text-green-400 font-semibold">High</span>
                        </p>
                      </div>

                      {/* Accuracy Metrics Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                          <div className="flex items-center space-x-2 mb-2">
                            <Target className="w-4 h-4 text-slate-400" />
                            <span className="text-slate-400 text-sm">Accuracy Score</span>
                          </div>
                          <div className="text-white text-3xl font-bold">95%</div>
                        </div>
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                          <div className="flex items-center space-x-2 mb-2">
                            <BarChart3 className="w-4 h-4 text-slate-400" />
                            <span className="text-slate-400 text-sm">Data Quality</span>
                          </div>
                          <div className="text-white text-xl font-semibold">Limited</div>
                        </div>
                      </div>

                      {/* Model Information */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-4">
                          <Settings className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">Model Information</h4>
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center py-2 border-b border-slate-700/50">
                            <span className="text-slate-400">Model Name:</span>
                            <span className="text-white font-medium">Keyword-based NLP</span>
                          </div>
                          <div className="flex justify-between items-center py-2 border-b border-slate-700/50">
                            <span className="text-slate-400">Model Version:</span>
                            <span className="text-white font-medium">v2.1</span>
                          </div>
                          <div className="flex justify-between items-center py-2 border-b border-slate-700/50">
                            <span className="text-slate-400">Algorithm:</span>
                            <span className="text-white font-medium">Keyword-based NLP</span>
                          </div>
                          <div className="flex justify-between items-center py-2 border-b border-slate-700/50">
                            <span className="text-slate-400">Training Data:</span>
                            <span className="text-white font-medium">8 emotion categories, 200+ keywords</span>
                          </div>
                          <div className="flex justify-between items-center py-2">
                            <span className="text-slate-400">Processing Time:</span>
                            <span className="text-white font-medium">~1.2s</span>
                          </div>
                        </div>
                      </div>

                      {/* Accuracy Insights */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-4">
                          <Sparkles className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">Accuracy Insights</h4>
                        </div>
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              Higher confidence scores indicate more reliable emotion detection
                            </p>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              Longer texts generally provide better accuracy due to more context
                            </p>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              Multiple emotion words increase prediction confidence
                            </p>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">Consider adding more text for improved accuracy</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <Target className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                      <p className="text-slate-400 text-lg">No accuracy data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="eda" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="space-y-8">
                      {/* Confusion Matrix */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-6">
                          <BarChart3 className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">Confusion Matrix</h4>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr>
                                <th className="text-slate-400 text-left p-2">Predicted →</th>
                                {emotions.map((emotion) => (
                                  <th key={emotion} className="text-slate-400 text-center p-2 min-w-[60px]">
                                    {emotion}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {confusionMatrix.map((row, index) => (
                                <tr key={row.emotion}>
                                  <td className="text-slate-300 font-medium p-2">{row.emotion}</td>
                                  {emotions.map((emotion) => (
                                    <td key={emotion} className="text-center p-2">
                                      <div
                                        className={`
                                        px-2 py-1 rounded text-sm font-medium
                                        ${
                                          row.emotion === emotion && row[emotion] > 0
                                            ? "bg-slate-600 text-white"
                                            : row[emotion] > 0
                                              ? "bg-slate-700/50 text-slate-300"
                                              : "text-slate-500"
                                        }
                                      `}
                                      >
                                        {row[emotion]}
                                      </div>
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        <div className="flex items-center space-x-6 mt-4 text-xs">
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                            <span className="text-slate-400">Correct Prediction (Primary)</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                            <span className="text-slate-400">Correct Prediction</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                            <span className="text-slate-400">Misclassification</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                            <span className="text-slate-400">Not Detected</span>
                          </div>
                        </div>
                      </div>

                      {/* Emotion Prevalence Analysis */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-6">
                          <BarChart3 className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">Emotion Prevalence Analysis</h4>
                        </div>
                        <div className="text-center py-8">
                          <div className="text-6xl mb-4">😐</div>
                          <p className="text-slate-400 mb-8">No emotions detected - text appears neutral</p>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                            <div className="text-center">
                              <div className="text-purple-400 text-lg font-semibold">Neutral</div>
                              <div className="text-slate-400 text-sm">Most Prevalent</div>
                            </div>
                            <div className="text-center">
                              <div className="text-blue-400 text-lg font-semibold">0%</div>
                              <div className="text-slate-400 text-sm">Dominance</div>
                            </div>
                            <div className="text-center">
                              <div className="text-blue-400 text-lg font-semibold">0</div>
                              <div className="text-slate-400 text-sm">High Intensity</div>
                            </div>
                            <div className="text-center">
                              <div className="text-yellow-400 text-lg font-semibold">Neutral</div>
                              <div className="text-slate-400 text-sm">Emotion Type</div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Text Analysis Statistics */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-6">
                          <TrendingUp className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">Text Analysis Statistics</h4>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                          <div className="text-center">
                            <div className="text-white text-3xl font-bold mb-2">{result.wordCount}</div>
                            <div className="text-slate-400 text-sm">Total Words</div>
                          </div>
                          <div className="text-center">
                            <div className="text-purple-400 text-3xl font-bold mb-2">
                              {result.breakdown.positive + result.breakdown.negative + result.breakdown.neutral}
                            </div>
                            <div className="text-slate-400 text-sm">Emotional Words</div>
                          </div>
                          <div className="text-center">
                            <div className="text-blue-400 text-3xl font-bold mb-2">
                              {result.breakdown.positive + result.breakdown.negative + result.breakdown.neutral}
                            </div>
                            <div className="text-slate-400 text-sm">Emotions Found</div>
                          </div>
                          <div className="text-center">
                            <div className="text-green-400 text-3xl font-bold mb-2">{result.confidence}%</div>
                            <div className="text-slate-400 text-sm">Avg Confidence</div>
                          </div>
                        </div>
                      </div>

                      {/* EDA Insights */}
                      <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50">
                        <div className="flex items-center space-x-2 mb-4">
                          <Sparkles className="w-5 h-5 text-slate-300" />
                          <h4 className="text-white font-semibold text-lg">EDA Insights</h4>
                        </div>
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              <span className="font-semibold">Dominant Pattern:</span> {result.sentiment} represents{" "}
                              {result.confidence}% of detected emotions
                            </p>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              <span className="font-semibold">Confidence Range:</span> {result.confidence}% -{" "}
                              {result.confidence}% across all emotions
                            </p>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                            <p className="text-slate-300 text-sm">
                              <span className="font-semibold">Intensity Distribution:</span>{" "}
                              {result.score > 3 ? "1" : "0"} high, {result.score > 1 && result.score <= 3 ? "1" : "0"}{" "}
                              medium, {result.score <= 1 ? "1" : "0"} low intensity emotions
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <Brain className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                      <p className="text-slate-400 text-lg">No EDA data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="summary" className="mt-8">
              <Card className="bg-slate-900/60 border-slate-700/50 backdrop-blur-sm shadow-xl">
                <CardContent className="p-8">
                  {result ? (
                    <div className="space-y-6">
                      <h3 className="text-white text-2xl font-bold mb-6">Analysis Summary</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 text-center hover:scale-105 transition-transform duration-300">
                          <div className="text-3xl mb-3">{result.emoji}</div>
                          <div className="text-white font-semibold">Sentiment</div>
                          <div className="text-slate-300 capitalize">{result.sentiment}</div>
                        </div>
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 text-center hover:scale-105 transition-transform duration-300">
                          <div className="text-3xl mb-3">📊</div>
                          <div className="text-white font-semibold">Confidence</div>
                          <div className="text-slate-300">{result.confidence}%</div>
                        </div>
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 text-center hover:scale-105 transition-transform duration-300">
                          <div className="text-3xl mb-3">📝</div>
                          <div className="text-white font-semibold">Words</div>
                          <div className="text-slate-300">{result.wordCount}</div>
                        </div>
                        <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/50 text-center hover:scale-105 transition-transform duration-300">
                          <div className="text-3xl mb-3">🎯</div>
                          <div className="text-white font-semibold">Intensity</div>
                          <div className="text-slate-300">{result.score}</div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <TrendingUp className="w-16 h-16 text-slate-600 mx-auto mb-6" />
                      <p className="text-slate-400 text-lg">No summary data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
